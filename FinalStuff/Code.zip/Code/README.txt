Project.py contains our main program.
ProjectTest.py contains the test used for the leave-one-out analysis as well as the code for the two other approaches.
The other files are support files.

The results will put in the map Results.